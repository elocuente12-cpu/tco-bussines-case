def lambda_handler(event, context):
    print('This is a test, event passed = ' + list(event))
